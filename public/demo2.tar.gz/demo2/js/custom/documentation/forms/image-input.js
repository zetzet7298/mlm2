/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!****************************************************************************!*\
  !*** ./resources/assets/core/js/custom/documentation/forms/image-input.js ***!
  \****************************************************************************/


// Class definition
var KTGeneralImageInputDemos = function () {
  // Private functions
  var _exampleBasic = function _exampleBasic() {};
  return {
    // Public Functions
    init: function init() {
      _exampleBasic();
    }
  };
}();

// On document ready
KTUtil.onDOMContentLoaded(function () {
  KTGeneralImageInputDemos.init();
});
/******/ })()
;