/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!********************************************************************************!*\
  !*** ./resources/assets/extended/js/custom/account/settings/signin-methods.js ***!
  \********************************************************************************/


// Class definition
var KTAccountSettingsSigninMethods = function () {
  // Private functions
  var initSettings = function initSettings() {
    // UI elements
    // var signInMainEl = document.getElementById('kt_signin_email');
    // var signInEditEl = document.getElementById('kt_signin_email_edit');
    var passwordMainEl = document.getElementById('kt_signin_password');
    var passwordEditEl = document.getElementById('kt_signin_password_edit');
    var password2MainEl = document.getElementById('kt_signin_password_2');
    var password2EditEl = document.getElementById('kt_signin_password_2_edit');

    // button elements
    var signInChangeEmail = document.getElementById('kt_signin_email_button');
    var signInCancelEmail = document.getElementById('kt_signin_cancel');
    var passwordChange = document.getElementById('kt_signin_password_button');
    var passwordCancel = document.getElementById('kt_password_cancel');
    var password2Change = document.getElementById('kt_signin_password_2_button');
    var password2Cancel = document.getElementById('kt_password_2_cancel');
    // toggle UI
    // signInChangeEmail.querySelector('button').addEventListener('click', function () {
    //     toggleChangeEmail();
    // });

    // signInCancelEmail.addEventListener('click', function () {
    //     toggleChangeEmail();
    // });

    passwordChange.querySelector('button').addEventListener('click', function () {
      toggleChangePassword();
    });
    passwordCancel.addEventListener('click', function () {
      toggleChangePassword();
    });
    password2Change.querySelector('button').addEventListener('click', function () {
      toggleChangePassword2();
    });
    password2Cancel.addEventListener('click', function () {
      toggleChangePassword2();
    });

    // var toggleChangeEmail = function () {
    //     signInMainEl.classList.toggle('d-none');
    //     signInChangeEmail.classList.toggle('d-none');
    //     signInEditEl.classList.toggle('d-none');
    // }

    var toggleChangePassword = function toggleChangePassword() {
      console.log(1);
      passwordMainEl.classList.toggle('d-none');
      passwordChange.classList.toggle('d-none');
      passwordEditEl.classList.toggle('d-none');
    };
    var toggleChangePassword2 = function toggleChangePassword2() {
      password2MainEl.classList.toggle('d-none');
      password2Change.classList.toggle('d-none');
      password2EditEl.classList.toggle('d-none');
    };
  };

  // var handleChangeEmail = function (e) {
  //     var validation;

  //     // form elements
  //     var form = document.getElementById('kt_signin_change_email');
  //     var submitButton = form.querySelector('#kt_signin_submit');

  //     validation = FormValidation.formValidation(
  //         form,
  //         {
  //             fields: {
  //                 email: {
  //                     validators: {
  //                         notEmpty: {
  //                             message: 'Email is required'
  //                         },
  //                         emailAddress: {
  //                             message: 'The value is not a valid email address'
  //                         }
  //                     }
  //                 },

  //                 password: {
  //                     validators: {
  //                         notEmpty: {
  //                             message: 'Password is required'
  //                         }
  //                     }
  //                 }
  //             },

  //             plugins: { //Learn more: https://formvalidation.io/guide/plugins
  //                 trigger: new FormValidation.plugins.Trigger(),
  //                 bootstrap: new FormValidation.plugins.Bootstrap5({
  //                     rowSelector: '.fv-row'
  //                 })
  //             }
  //         }
  //     );

  //     submitButton.addEventListener('click', function (e) {
  //         e.preventDefault();

  //         validation.validate().then(function (status) {
  //             if (status === 'Valid') {

  //                 // Show loading indication
  //                 submitButton.setAttribute('data-kt-indicator', 'on');

  //                 // Disable button to avoid multiple click
  //                 submitButton.disabled = true;

  //                 // Send ajax request
  //                 axios.post(form.getAttribute('action'), new FormData(form))
  //                     .then(function (response) {
  //                         // Show message popup. For more info check the plugin's official documentation: https://sweetalert2.github.io/
  //                         Swal.fire({
  //                             text: "Your email has been successfully changed.",
  //                             icon: "success",
  //                             buttonsStyling: false,
  //                             confirmButtonText: "Ok, got it!",
  //                             customClass: {
  //                                 confirmButton: "btn font-weight-bold btn-light-primary"
  //                             }
  //                         });
  //                     })
  //                     .catch(function (error) {
  //                         let dataMessage = error.response.data.message;
  //                         let dataErrors = error.response.data.errors;

  //                         for (const errorsKey in dataErrors) {
  //                             if (!dataErrors.hasOwnProperty(errorsKey)) continue;
  //                             dataMessage += "\r\n" + dataErrors[errorsKey];
  //                         }

  //                         if (error.response) {
  //                             Swal.fire({
  //                                 text: dataMessage,
  //                                 icon: "error",
  //                                 buttonsStyling: false,
  //                                 confirmButtonText: "Ok, got it!",
  //                                 customClass: {
  //                                     confirmButton: "btn btn-primary"
  //                                 }
  //                             });
  //                         }
  //                     })
  //                     .then(function () {
  //                         // always executed
  //                         // Hide loading indication
  //                         submitButton.removeAttribute('data-kt-indicator');

  //                         // Enable button
  //                         submitButton.disabled = false;
  //                     });

  //             } else {
  //                 Swal.fire({
  //                     text: "Sorry, looks like there are some errors detected, please try again.",
  //                     icon: "error",
  //                     buttonsStyling: false,
  //                     confirmButtonText: "Ok, got it!",
  //                     customClass: {
  //                         confirmButton: "btn font-weight-bold btn-light-primary"
  //                     }
  //                 });
  //             }
  //         });
  //     });
  // }

  var handleChangePassword = function handleChangePassword(formId, submitButtonId) {
    var validation;

    // form elements
    var form = document.getElementById(formId);
    var submitButton = form.querySelector("#".concat(submitButtonId));
    validation = FormValidation.formValidation(form, {
      fields: {
        current_password: {
          validators: {
            notEmpty: {
              message: 'Current Password is required'
            }
          }
        },
        password: {
          validators: {
            notEmpty: {
              message: 'New Password is required'
            }
          }
        },
        password_confirmation: {
          validators: {
            notEmpty: {
              message: 'Confirm Password is required'
            },
            identical: {
              compare: function compare() {
                return form.querySelector('[name="password"]').value;
              },
              message: 'The password and its confirm are not the same'
            }
          }
        }
      },
      plugins: {
        //Learn more: https://formvalidation.io/guide/plugins
        trigger: new FormValidation.plugins.Trigger(),
        bootstrap: new FormValidation.plugins.Bootstrap5({
          rowSelector: '.fv-row'
        })
      }
    });
    submitButton.addEventListener('click', function (e) {
      e.preventDefault();
      validation.validate().then(function (status) {
        if (status == 'Valid') {
          // Show loading indication
          submitButton.setAttribute('data-kt-indicator', 'on');

          // Disable button to avoid multiple click
          submitButton.disabled = true;

          // Send ajax request
          axios.post(form.getAttribute('action'), new FormData(form)).then(function (response) {
            // Show message popup. For more info check the plugin's official documentation: https://sweetalert2.github.io/
            Swal.fire({
              text: "Your password has been successfully reset.",
              icon: "success",
              buttonsStyling: false,
              confirmButtonText: "Ok, got it!",
              customClass: {
                confirmButton: "btn font-weight-bold btn-light-primary"
              }
            });
          })["catch"](function (error) {
            var dataMessage = error.response.data.message;
            var dataErrors = error.response.data.errors;
            for (var errorsKey in dataErrors) {
              if (!dataErrors.hasOwnProperty(errorsKey)) continue;
              dataMessage += "\r\n" + dataErrors[errorsKey];
            }
            if (error.response) {
              Swal.fire({
                text: dataMessage,
                icon: "error",
                buttonsStyling: false,
                confirmButtonText: "Ok, got it!",
                customClass: {
                  confirmButton: "btn btn-primary"
                }
              });
            }
          }).then(function () {
            // always executed
            // Hide loading indication
            submitButton.removeAttribute('data-kt-indicator');

            // Enable button
            submitButton.disabled = false;
          });
        } else {
          Swal.fire({
            text: "Sorry, looks like there are some errors detected, please try again.",
            icon: "error",
            buttonsStyling: false,
            confirmButtonText: "Ok, got it!",
            customClass: {
              confirmButton: "btn font-weight-bold btn-light-primary"
            }
          });
        }
      });
    });
  };
  var formId = 'kt_signin_change_password';
  var submitButtonId = 'kt_password_submit';
  var formId2 = 'kt_signin_change_password_2';
  var submitButtonId2 = 'kt_password_2_submit';
  // Public methods
  return {
    init: function init() {
      initSettings();
      // handleChangeEmail();
      handleChangePassword(formId, submitButtonId);
      handleChangePassword(formId2, submitButtonId2);
    }
  };
}();

// On document ready
KTUtil.onDOMContentLoaded(function () {
  KTAccountSettingsSigninMethods.init();
});
/******/ })()
;